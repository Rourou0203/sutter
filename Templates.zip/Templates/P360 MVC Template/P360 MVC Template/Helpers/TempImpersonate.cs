﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Security.Principal;
using System.DirectoryServices.AccountManagement; 

namespace P360.Helpers
{
    public static class TempImpersonate
    {

        public static string GetUserName()
        {
            string userName = "";
            try
            {
                // Special thanks to:  http://stackoverflow.com/questions/10846909/asp-net-mvc-windows-authentiaction-and-directoryservices-get-mail-address-of-t

                using (HostingEnvironment.Impersonate())
                {
                    var identityName = HttpContext.Current.User.Identity.Name;

                    using (var context = new PrincipalContext(ContextType.Domain, "sutter-chs", null, ContextOptions.Negotiate | ContextOptions.SecureSocketLayer))
                    using (var userPrincipal = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, identityName))
                    {
                        userName = userPrincipal.GivenName + " " + userPrincipal.Surname;
                    }
                }

                return userName;
            }
            catch
            {
                return "";
            }
            finally
            {
            }
        }

        public static string GetUserPhone()
        {
            string phone = "";
            try
            {
                // Special thanks to:  http://stackoverflow.com/questions/10846909/asp-net-mvc-windows-authentiaction-and-directoryservices-get-mail-address-of-t

                using (HostingEnvironment.Impersonate())
                {
                    var identityName = HttpContext.Current.User.Identity.Name;

                    using (var context = new PrincipalContext(ContextType.Domain, "sutter-chs", null, ContextOptions.Negotiate | ContextOptions.SecureSocketLayer))
                    using (var userPrincipal = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, identityName))
                    {
                        phone = userPrincipal.VoiceTelephoneNumber;
                    }
                }

                return phone;
            }
            catch
            {
                return "";
            }
            finally
            {
            }
        }
    }
}