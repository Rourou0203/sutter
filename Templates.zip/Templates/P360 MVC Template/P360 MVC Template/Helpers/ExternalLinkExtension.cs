﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel;
using System.Configuration;

namespace P360.Helpers
{
    public static class ExternalLinkExtension
    {

        public static MvcHtmlString ExternalLink(this HtmlHelper helper, string url, string linkText)
        {
            return MvcHtmlString.Create(String.Format("<a href=\"{0}\">{1}</a>", url, linkText));
        }

        public static MvcHtmlString ExternalImageLink(this HtmlHelper helper, string url, string imageUri)
        {
            return MvcHtmlString.Create(String.Format("<a href=\"{0}\"><img class=\"pull-left\" style=\"margin-right:5px;\" src=\"{1}\" /></a>", url, imageUri)); 
        }
    }
}